﻿using System;
using System.Collections.Generic;
using System.Linq;
using ThirdPartyTools;

namespace FileData
{
    public static class Program
    {
        public static void Main(string[] args)
        {
			//Used the Main Procedure, did not create new procedure
			List<string> verList = new List<string>();  // List to hold the version flags
			verList.Add("-v"); verList.Add("--v"); verList.Add("/v"); verList.Add("--version");

			List<string> sizList = new List<string>(); // List to hold the size flags
			verList.Add("-s"); verList.Add("--s"); verList.Add("/s"); verList.Add("--size");

			if (args.Length > 1) // If greater than 2 arguments then proceed as we need the flag and the file number
			{
				FileDetails fDet = new FileDetails(); // Create object for the Thirdparty App

				string argument1 = args[0]; // flag
				string argument2 = args[1]; // filename

				foreach (string ver in verList)
				{
					if (argument1.Contains(ver))
					{
						Console.WriteLine("Version Details Below");
						//Calling the procedure Size and displaying the version details in-line
						Console.WriteLine(fDet.Version(argument2)); 
						break;
					}
				}

				foreach (string siz in sizList)
				{
					if (argument1.Contains(siz))
					{
						Console.WriteLine("Size Details Below");
						//Calling the procedure Size and displaying the size details in-line						
						Console.WriteLine(fDet.Size(argument2));
						break;
					}
				}
			}   
        }
    }
}
